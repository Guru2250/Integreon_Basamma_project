import LoginPage from './Components/LoginPage';
import Logobar from './Components/Logobar';

function App() {
  return (
    <div className="App">
      <Logobar/>
      <LoginPage/>
    </div>
  );
}
export default App;
