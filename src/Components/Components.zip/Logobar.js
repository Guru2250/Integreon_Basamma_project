import React from 'react';
import styled from 'styled-components';

const Logobar = () => {
  return (
    <LogoDiv>
        <Logo src="./Images/logo.png" alt="" />
    </LogoDiv>
  )
}

export default Logobar

const LogoDiv=styled.div`
  background-color: #282f36d8;
  height: 60px;
  display: flex;
  align-items: center;
`;

const Logo=styled.img`
  height: 39.65px;
  width: 130px;
  object-fit: contain;
  width: fit-content;
  display: block;
  padding-left: 10vw;
`;