import React from 'react';
import styled from "styled-components";
import FormUnit from './FormUnit';
import backgroundImage from "./Images/img2.jpg";
import EmpImage from "./Images/hero-image.png";
import CornerImage1 from "./Images/BackSquare.png";
import CornerImage2 from "./Images/corner.png";


const LoginPage = () => {
  return (
    <MainDiv>
      <LeftDiv>
          <Image src={EmpImage} alt="" />
          <SquareImg src={CornerImage1} alt="" />
          <SquareImg style={{"z-index":"3"}} src={CornerImage2} alt="" />
          <Paragraph>
          "Integreon's expertise and willingness to innovate allows me to
          deliver increased efficiency to my key internal clients, our
          attorneys, so they can focus on higher-value work."
          </Paragraph>
      </LeftDiv>
      <div style={{width:"100%"}}>
        <FormUnit/>
      </div>
    </MainDiv>
  )
}

export default LoginPage

const MainDiv=styled.div`
	height:fit-content;
	background:url(${backgroundImage});
	background-repeat:no-repeat;
	background-size:70%;
	background-position:right;
	background-color:#f7f7f7;
	display:flex;
`;

const LeftDiv=styled.div`
	box-sizing: border-box;
	position: relative;
	width: 100%;
`;

const Image=styled.img`
	position: relative;
	padding-top: 30px;
	display: block;
	width: 75%;
	z-index: 2;
`;
const SquareImg=styled.img`
	position: absolute;
	top:0;
	margin-top:80px;
	left:0;
	margin-left:250px;
	height:300px;
`;


const Paragraph=styled.p`
	text-overflow: wrap;
	font-family: aktiv-grotesk, sans-serif;
	font-size: 20px;
	width: 78%;
	text-align: left;
	padding-left: 30px;
`;